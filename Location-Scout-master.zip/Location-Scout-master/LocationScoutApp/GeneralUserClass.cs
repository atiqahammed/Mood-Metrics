﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LocationScoutApp
{
    public class GeneralUserClass
    {
        public string username { get; set; }

    }
}