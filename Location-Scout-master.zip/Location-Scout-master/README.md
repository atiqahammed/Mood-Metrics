# Location-Scout 
![](https://img.shields.io/badge/.NET--blue.svg) ![](https://img.shields.io/badge/C%23--brightgreen.svg) 
  This is an application to scout information about a location.
  This information can be in the form of Crime Data, Weather Data, Business Data, News etc.(Version 1.0)
  
  We are also adding feature to automatically plan a complete tour of location based input like cost, time and duration of Stay.
