# NetLogSystem
Log System to  Distributed Computing Systems . We using DotNet Core Microservices technologies
