# Online-Auction
 An Auction site where user can upload or buy products with proper bidding.Developed By ASP.NET MVC. I am uploading The Beta Version.
