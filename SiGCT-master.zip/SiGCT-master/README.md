# SiGCT
Sistema de Gestão de Contas Telefonicas


### O que é SiGCT?
Sistema web para ler e gerir contas telefonicas disponibilizadas no padrão Febraban V3, **encontra-se em fase de desenvolvimento**.  

### Tecnologia  
Desenvolvido utilizando Asp.net MVC, NHibernate e SQLite.  

### Links Uteis
* [Informações do padrão febraban V3](https://febraban.org.br/Acervo1.asp?id_texto=201&id_pagina=173&palavra=)

* [Link do arquivo XLS](https://febraban.org.br/LerArquivo.asp?Tabela=Home_Arquivos&codigo=id_arquivo&campo1=arquivo&campo2=QtdeAcessos&id_codigo=242&campo3=arquivos/)

