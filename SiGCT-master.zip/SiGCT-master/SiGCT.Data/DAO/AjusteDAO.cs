﻿using NHibernate.Helper.Generics;
using SiGCT.Models;

namespace SiGCT.Data.DAO
{
    public class AjusteDAO : GenericDAO<long, Ajuste>
    {

    }
}