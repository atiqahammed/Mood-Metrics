﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using NHibernate.Helper.Generics;
using SiGCT.Models;

namespace SiGCT.Data.DAO
{
    public class CentroCustoDAO : GenericDAO<long, CentroCusto>
    {

    }
}