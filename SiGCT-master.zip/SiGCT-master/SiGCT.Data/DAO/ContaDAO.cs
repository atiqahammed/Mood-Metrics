﻿using NHibernate.Helper.Generics;
using SiGCT.Models;

namespace SiGCT.Data.DAO
{
    public class ContaDAO : GenericDAO<long, Conta>
    {

    }
}