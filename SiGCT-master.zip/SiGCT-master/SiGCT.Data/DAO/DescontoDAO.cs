﻿using NHibernate.Helper.Generics;
using SiGCT.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SiGCT.Data.DAO
{
    public class DescontoDAO : GenericDAO<long, Desconto>
    {

    }
}