﻿using NHibernate.Helper.Generics;
using SiGCT.Models;

namespace SiGCT.Data.DAO
{
    public class EnderecosRecursoDAO : GenericDAO<long, EnderecosRecurso>
    {

    }
}