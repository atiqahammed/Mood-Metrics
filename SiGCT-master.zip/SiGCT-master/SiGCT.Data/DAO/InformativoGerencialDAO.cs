﻿using NHibernate.Helper.Generics;
using SiGCT.Models;

namespace SiGCT.Data.DAO
{
    public class InformativoGerencialDAO : GenericDAO<long, InformativoGerencial>
    {

    }
}