﻿using NHibernate.Helper.Generics;
using SiGCT.Models;

namespace SiGCT.Data.DAO
{
    public class NotaFiscalDAO : GenericDAO<long, NotaFiscal>
    {

    }
}