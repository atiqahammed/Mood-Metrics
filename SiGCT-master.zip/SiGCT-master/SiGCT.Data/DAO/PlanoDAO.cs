﻿using NHibernate.Helper.Generics;
using SiGCT.Models;

namespace SiGCT.Data.DAO
{
    public class PlanoDAO : GenericDAO<long, Plano>
    {

    }
}