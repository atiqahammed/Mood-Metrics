﻿using NHibernate.Helper.Generics;
using SiGCT.Models;

namespace SiGCT.Data.DAO
{
    public class RecursoDAO : GenericDAO<long, Recurso>
    {

    }
}