﻿using NHibernate.Helper.Generics;
using SiGCT.Models;

namespace SiGCT.Data.DAO
{
    public class ResumoDAO : GenericDAO<long, Resumo>
    {

    }
}