﻿using NHibernate.Helper.Generics;
using SiGCT.Models;

namespace SiGCT.Data.DAO
{
    public class ServicoDAO : GenericDAO<long, Servico>
    {

    }
}