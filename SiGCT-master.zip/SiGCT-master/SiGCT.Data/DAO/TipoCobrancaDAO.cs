﻿using NHibernate.Helper.Generics;
using SiGCT.Models;

namespace SiGCT.Data.DAO
{
    public class TipoCobrancaDAO : GenericDAO<long, TipoCobranca>
    {

    }
}