﻿using NHibernate.Helper.Generics;
using SiGCT.Models;

namespace SiGCT.Data.DAO
{
    public class TraillerDAO : GenericDAO<long, Trailler>
    {

    }
}