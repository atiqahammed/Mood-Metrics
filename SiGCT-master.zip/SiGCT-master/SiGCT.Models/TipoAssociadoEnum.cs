﻿using System.ComponentModel;

namespace SiGCT.Models
{
    /// <summary>
    /// 
    /// </summary>
    public enum TipoAssociadoEnum
    {
        [Description("Associado a Conta")]
        C,

        [Description("Associado ao Recurso")]
        R
    }
}