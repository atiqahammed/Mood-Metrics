﻿using System.ComponentModel;

namespace SiGCT.Models
{
    public enum TipoPontaEnum
    {
        [Description("Ponta A")]
        A,

        [Description("Ponta B")]
        B,

        [Description("Ponta C")]
        C
    }
}