﻿namespace SytnerCollege.Models.CollegeViewModels
{
    /*
     */

    public class AssignedCourseData
    {
        public int CourseID { get; set; }
        public string Title { get; set; }
        public bool Assigned { get; set; }
    }
}
