﻿namespace VolleyManagement.Crosscutting.Contracts.FeatureToggles
{
    using FeatureToggle.Toggles;
    public class DebugMode : SimpleFeatureToggle
    {

    }
}