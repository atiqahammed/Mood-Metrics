﻿namespace VolleyManagement.Data.Contracts
{
    /// <summary>
    /// Container for constants.
    /// </summary>
    public static class Constants
    {
        public const string ENTITY_ID_KEY = "EntityId";

        public const int START_DATABASE_ID_VALUE = 1;
    }
}
