﻿namespace VolleyManagement.Data.Contracts
{
    /// <summary>
    /// Represents Object Query parameters
    /// </summary>
    public interface IQueryCriteria
    {
    }
}