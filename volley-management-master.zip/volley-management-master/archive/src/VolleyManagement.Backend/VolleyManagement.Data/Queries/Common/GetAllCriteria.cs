﻿namespace VolleyManagement.Data.Queries.Common
{
    using Contracts;

    /// <summary>
    /// Query criterion to read all Tournaments
    /// </summary>
    public class GetAllCriteria : IQueryCriteria
    {
    }
}