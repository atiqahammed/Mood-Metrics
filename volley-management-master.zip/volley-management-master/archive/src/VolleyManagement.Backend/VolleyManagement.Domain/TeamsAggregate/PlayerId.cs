﻿namespace VolleyManagement.Domain.TeamsAggregate
{
    public class PlayerId
    {
        public int Id { get; }
        public PlayerId(int id) { Id = id; }
    }
}
