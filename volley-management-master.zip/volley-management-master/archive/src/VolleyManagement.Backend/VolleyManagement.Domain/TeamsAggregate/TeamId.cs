﻿namespace VolleyManagement.Domain.TeamsAggregate
{
    public class TeamId
    {
        public int Id { get; }
        public TeamId(int id) { Id = id; }
    }
}
