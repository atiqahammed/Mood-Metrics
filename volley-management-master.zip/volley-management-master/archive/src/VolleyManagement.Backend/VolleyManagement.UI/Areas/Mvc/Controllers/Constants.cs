﻿namespace VolleyManagement.UI.Areas.Mvc.Controllers
{
    /// <summary>
    /// Container for constants.
    /// </summary>
    public static class Constants
    {
        public const string TEAM_PHOTO_PATH = "/Content/Photo/Teams/{0}.jpg";
    }
}