namespace VolleyManagement.UI.Areas.Mvc.ViewModels.GameReports
{
    using System;

    public class DivisionStandingsBase
    {
        public DateTime? LastUpdateTime { get; set; }
    }
}
