namespace VolleyManagement.UI.Areas.WebApi.ViewModels.GameReports
{
    using System;

    public class DivisionStandingsViewModelBase
    {
        public DateTime? LastUpdateTime { get; set; }

        public string DivisionName { get; set; }
    }
}
