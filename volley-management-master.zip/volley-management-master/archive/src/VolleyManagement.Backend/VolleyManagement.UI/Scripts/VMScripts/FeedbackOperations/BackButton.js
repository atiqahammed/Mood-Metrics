﻿'use strict';
$(document).ready(function () {
  $('#feedback-return').click(function () {
    window.history.back();
  });
});